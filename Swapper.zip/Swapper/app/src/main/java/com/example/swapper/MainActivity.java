package com.example.swapper;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editText1, editText2;
    Button btnSwap, btnCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);
        btnSwap = findViewById(R.id.btnSwap);
        btnCheck = findViewById(R.id.btnCheck); // ✅ fixed typo

        btnSwap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temp = editText1.getText().toString();
                editText1.setText(editText2.getText().toString());
                editText2.setText(temp);
            }
        });

        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                String text1 = editText1.getText().toString();
                String text2 = editText2.getText().toString();
                if (text1.equalsIgnoreCase(text2)){
                    intent.putExtra("same", "The Same");
                    startActivity(intent);

                }
                else {
                    intent.putExtra("same", "Not The Same");
                    startActivity(intent);
                }

                startActivity(intent);
            }
        });
    }
}
