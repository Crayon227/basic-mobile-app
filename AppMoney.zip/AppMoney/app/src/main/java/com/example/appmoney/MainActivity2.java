package com.example.appmoney;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;




public class MainActivity2 extends AppCompatActivity {

    public static final String EXTRA_NAME = "com.example.appmoney.MESSAGE";
    public static final String EXTRA_MOBILE = "com.example.appmoney.EXTRA_MOBILE";
    TextView entNum, entV, registration;
    EditText mobileNo, firstName;
    CheckBox checkboxAgree;
    Button btnNext, buttonBack;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        mobileNo = findViewById(R.id.etMobileNumber);
        checkboxAgree = findViewById(R.id.checkboxAgree);
        btnNext = findViewById(R.id.btnNext);
        buttonBack = findViewById(R.id.back);
        entNum = findViewById(R.id.entNum);
        entV = findViewById(R.id.ref63);
        registration = findViewById(R.id.regisTration);
        firstName = findViewById(R.id.user);

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
                finish();
        }
    });
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fName = firstName.getText().toString().trim();
                String mNo = mobileNo.getText().toString().trim();

                Intent nextIntent = new Intent(MainActivity2.this, MainActivity3.class);
                nextIntent.putExtra(EXTRA_NAME, fName);
                nextIntent.putExtra(EXTRA_MOBILE, mNo);
                startActivity(nextIntent);
            }
        });
}}