package com.example.appmoney;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.appmoney.MESSAGE";
    TextView welcomeText, sloganText1, sloganText2, titleText;
    ImageView logoImage, bottomImage;
    Button createAccountButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize
        titleText = findViewById(R.id.Bohol);
        welcomeText = findViewById(R.id.textView);
        sloganText1 = findViewById(R.id.textView2);
        sloganText2 = findViewById(R.id.textView3);
        logoImage = findViewById(R.id.imageView2);
        bottomImage = findViewById(R.id.imageView5);
        createAccountButton = findViewById(R.id.createAcc);


        createAccountButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // Link
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });
    }
}
